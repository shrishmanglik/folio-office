from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
npx = shutil.which("npx.cmd") or shutil.which("npx")
if not npx:
    raise SystemExit("npx was not found")

mutants = [
    (
        "MA10",
        root / "src/App.tsx",
        b"templateBatchQueue.current.then(async()",
        b"Promise.resolve().then(async()",
        "src/App.four-in-one.test.tsx",
    ),
    (
        "MA13",
        root / "src/App.tsx",
        b"Boolean(file)&&publishedIds.has(file.id)",
        b"Boolean(file)",
        "src/App.four-in-one.test.tsx",
    ),
    (
        "MW04",
        root / "src/Workspace.tsx",
        b"p.onCreate(seed.kind,seed.name,seed.data,seed.templateId)",
        b"p.onCreate(seed.kind,seed.name,seed.data)",
        "src/FolioSovereignCommandSuite.test.tsx",
    ),
]

results = []
for mutant, path, before, after, test_file in mutants:
    original = path.read_bytes()
    original_hash = hashlib.sha256(original).hexdigest()
    if original.count(before) < 1:
        raise SystemExit(f"{mutant}: exact source pattern missing")
    changed = original.replace(before, after, 1)
    try:
        path.write_bytes(changed)
        log = evidence / f"mutant-{mutant}.txt"
        with log.open("wb") as output:
            completed = subprocess.run(
                [npx, "vitest", "run", test_file, "--maxWorkers=1"],
                cwd=root,
                stdout=output,
                stderr=subprocess.STDOUT,
                check=False,
            )
        results.append(
            {
                "mutant": mutant,
                "exit": completed.returncode,
                "killed": completed.returncode != 0,
                "log": log.name,
                "source_sha256": original_hash,
            }
        )
    finally:
        path.write_bytes(original)
        if hashlib.sha256(path.read_bytes()).hexdigest() != original_hash:
            raise SystemExit(f"{mutant}: source restoration failed")

(evidence / "mutation-results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
print(json.dumps(results))
if not all(result["killed"] for result in results):
    raise SystemExit(1)
